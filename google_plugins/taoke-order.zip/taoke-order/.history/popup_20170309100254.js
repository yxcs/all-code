setInterval(() => {
  console.log('running');
  document.body.innerHTML = 'in popup.js';
}, 100);

chrome.extension.onMessage.addListener(function(log) {
  console.log(log);
});