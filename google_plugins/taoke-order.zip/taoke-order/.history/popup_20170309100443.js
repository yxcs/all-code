chrome.extension.onMessage.addListener(function(log) {
  console.log(log);
});