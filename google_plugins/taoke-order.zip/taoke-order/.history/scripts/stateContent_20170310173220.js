if (locaiont.href === 'http://pub.alimama.com/myunion.htm#!/report/zone/zone_self) {
  window.onload = () => {
    let cookies = document.cookie.split(';');
    let _tb_token_ = '';
    let startTime = '';
    let endTime = '';
    let queryType = 1;
    let url = '';
    let tbkData = [];
    let toPage = 0;
    let total = 0;
    let totalPage = 0;
    let perPageSize = 2000;
    let lastGet = 0;
    let day = 0;
    let month = 0;
    let year = 0;
    let req = null;

    function updateDate () {
      let date = new Date() - 24 * 3600 * 1000;
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let day = date.getDate();
      if (month < 10) {
        month = '0' + month.toString();
      }
      if (day < 9) {
        day = '0' + day.toString();
      }
      startTime = year + '-' + month + '-' + day;
      endTime = startTime;
    }

    let downloadBtn = null;
    let getDownLoad = new Promise((resolve, rejected) => {
      let intervalId = setInterval(() => {
        downloadBtn = document.querySelector('[title="下载报表"]');
        if (downloadBtn) {
          clearInterval(intervalId);
          resolve();
        }
      }, 500);
    });
    getDownLoad.then(() => {
      updateDate();
      let href = `/report/selfRpt.json?DownloadID=DOWNLOAD_REPORT_REBORN_DETAIL&adzoneId=&startTime=${startTime}&endTime=${endTime}`;
      console.log(href);
      downloadBtn.href = href;
      downloadBtn.click();
      console.log('download');
    });
    setInterval(() => {
      location.reload(true);
    }, 3600 * 1000);
  };
}