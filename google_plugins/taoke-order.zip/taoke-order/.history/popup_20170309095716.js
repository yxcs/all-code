setInterval(() => {
  console.log('running');
  document.body.innerHTML = 'in popup.js';
}, 100);