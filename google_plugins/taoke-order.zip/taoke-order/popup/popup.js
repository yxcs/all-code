let btn = document.querySelector('#restart');
let btn1 = document.querySelector('#restore');

btn.addEventListener('click', function (event) {
  chrome.runtime.sendMessage({
    type: 'reboot'
  })
})

btn1.addEventListener('click', function (event) {
  chrome.runtime.sendMessage({
    type: 'restore'
  })
})