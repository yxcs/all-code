﻿let taokeId = null;
let resetId = null;
let stateId = null;
let rightId = null;
let alimamaId = null;
let loginId = null;
let thirdId = null;
let taokeTimeout = null;
let resetTimeout = null;
let stateTimeout = null;
let alimamaTimeout = null;
let loginTimeout = null;
let thirdTimeout = null;
let alimamaInterval = null;
let urlIndex = 0;
let byScript = false;
let loginTime = 0;
let pubOpen = false;
let sessionUrlList = [
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/myunion/overview`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/myunion/message`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/self/items`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/self/shops`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/self/links`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/taobao/widget_publish`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/taobao/coupon`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/taobao/software`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/act/activity`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/self/activity`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/act/activity_seller`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/act/activity_cpa`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/extra/aliyun`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/promo/extra/alitrip_intro`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/site/site`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/zone/zone`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/channel/channel`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/campaign/campaign`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/software/list`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/manage/act/activity_mypub`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/site/site`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_widget`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_channel`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_api`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_extra`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_cpa`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_software`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/zone/zone_act`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/detail/ruyitou`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/detail/rights`,
  `http://pub.alimama.com/myunion.htm?spm=getSpm#!/report/detail/3rdrights`,
  `http://pub.alimama.com/`,
  ''
];

let urlLen = sessionUrlList.length;

// 请求通知权限
if (Notification.permission !== 'granted') {
  Notification.requestPermission();
}

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   if (message === 'init') {
//     // 第一个插件打开后，开始再新建一个窗口

//     // openResetData();
//   }
// });


// 每8个小时自动重启
setInterval(_ => {
  reboot('AUTO');
  console.log(`${new Date().toLocaleString()} 重启调用`);
}, 60 * 60 * 1000 * 8)

chrome.runtime.onMessage.addListener(message => {
  if (message.type === 'login-succeed') {
    pubOpen = false;
    if (message.spm) {
      localStorage.setItem('spm', message.spm);
      !taokeId && openTbkWin();
      !stateId && openStateWin();
      // !rightId && openRightsWin();
      if (localStorage.getItem('target') && localStorage.getItem('sign_account')) {
        !alimamaId && new Notification('爬订单插件初始化成功！');
        if (localStorage.getItem('username') && localStorage.getItem('password')) {
          new Notification('已成功抓取用户信息，插件将开启自动登录！')
          loginTime = Date.now();
        } else {
          new Notification('未成功抓取用户信息，插件无法开启自动登录！可以重启插件，重新登录。')
        }
      } else {
        !alimamaId && new Notification('爬订单插件初始化失败！请重启插件重新登陆http://pub.alimama.com')
      }
      if (!alimamaId) {
        openAlimamaWin();
      }
    }
  } else if (message.type === 'reboot') {
    reboot('BY_HAND');
  } else if (message.type === 'restore') {
    openTbkWinRestore()
  } else if (message.type === 'get-userinfo') {
    !localStorage.getItem('username') &&
      localStorage.setItem('username', message.username);
    !localStorage.getItem('password') &&
      localStorage.setItem('password', message.password);

    // 开启pub.alimama.com
    !pubOpen && setTimeout(_ => {
      chrome.tabs.create({
        url: 'http://pub.alimama.com'
      }, pubTab => {

        // 1min后关闭所有页面
        setTimeout(_ => {
          chrome.tabs.query({
            url: '<all_urls>'
          }, tabs => {
            let extensionIndex = -1;
            tabs.forEach((tab, index) => {
              if (tab.url.indexOf('chrome://extensions') !== -1) {
                extensionIndex = index;
              }
            })
            tabs.splice(extensionIndex, 1);
            tabs.forEach(tab => {
              if (tab.id !== taokeId &&
                tab.id !== stateId &&
                tab.id !== alimamaId &&
                tab.id !== thirdId &&
                tab.id !== rightId &&
                tab.id !== loginId &&
                tab.id !== resetId &&
                tab.id !== thirdId ) {
                chrome.tabs.remove(tab.id)
              }
            })
          })
        }, 60000)
      });
    }, 20000)
    pubOpen = true;
  }
})

chrome.webRequest.onBeforeRequest.addListener(details => {
  if (details.url.split('?').length === 2) {
    let obj = parseUrlToObj(details.url.split('?')[1]);
    obj.sign_account && localStorage.setItem('sign_account', obj.sign_account);
    obj.target && localStorage.setItem('target', obj.target);
  }
}, {
  urls: [
    'https://login.taobao.com/*'
  ]
})


chrome.windows.onRemoved.addListener((tabId) => {
  if (tabId === taokeId) {
    clearTimeout(taokeTimeout);
    openTbkWin();
  } else if (tabId === stateId) {
    clearTimeout(stateTimeout);
    openStateWin();
  }else if (tabId === rightId) {
    clearTimeout(stateTimeout);
    openRightsWin();
  } else if (tabId === alimamaId) {
    clearTimeout(alimamaTimeout);
    openAlimamaWin();
  } else if (tabId === resetId) {
    // openResetData();
  } else if (tabId === thirdId) {

    // 第三方服务商窗口关闭，开启淘宝客订单窗口
    clearTimeout(thirdTimeout);
    openTbkWin();
  } else if (tabId === loginId && alimamaId === null) {
    clearTimeout(loginTimeout);
    openAlimamaWin();
  }
});

function reboot (type) {
  if (type === 'BY_HAND') {
    // 重启相关操作
    // 关闭所有阿里妈妈页面
    chrome.tabs.query({
      url: '<all_urls>'
    }, tabs => {
      clearTimeout(taokeTimeout);
      clearTimeout(stateTimeout);
      clearTimeout(alimamaTimeout);
      clearTimeout(thirdTimeout);
      clearTimeout(loginTimeout);
      clearTimeout(alimamaTimeout);
      taokeId = null;
      taokeTimeout = null;
      stateId = null;
      rightId = null;
      stateTimeout = null;
      alimamaId = null;
      alimamaTimeout = null;
      thirdId = null;
      thirdTimeout = null;
      alimamaTimeout = null;
      loginTimeout = null;
      loginId = null;
      alimamaId = null;
      tabs.forEach(item => {
        chrome.tabs.remove(item.id)
      })
      // 关掉爬数据的三个小窗-
      alimamaId = null;
    })

    // 新开一个页面用来账号登陆
    chrome.windows.create({
      url: 'chrome://extensions/',
      top: 0,
      left: 0,
      width: 800,
      height: 800,
      focused: true
    }, _ => {
      chrome.tabs.create({
        url: 'http://www.alimama.com/member/logout.htm?forward=http://pub.alimama.com/'
      }, logoutTab => {
        setTimeout(_ => {
          chrome.tabs.create({
            url: 'https://login.taobao.com/member/login.jhtml?style=minisimple&from=alimama&redirectURL=http://login.taobao.com/member/taobaoke/login.htm?is_login=1&full_redirect=true&c_isScure=true&quicklogin=true'
          }, loginTab => {
            setTimeout(_ => {
              chrome.tabs.sendMessage(loginTab.id, {
                type: 'send-userinfo',
                username: localStorage.getItem('username'),
                password: localStorage.getItem('password')
              })
            }, 10000)
          })
          chrome.tabs.remove(logoutTab.id)
        }, 2000)
      })
    });
  } else if (type === 'AUTO') {

    // 新开一个页面用来账号登陆
    chrome.windows.create({
      url: 'chrome://extensions/',
      top: 0,
      left: 0,
      width: 800,
      height: 800,
      focused: true
    }, _ => {
      chrome.tabs.create({
        url: 'http://www.alimama.com/member/logout.htm?forward=http://pub.alimama.com/'
      }, logoutTab => {
        setTimeout(_ => {
          chrome.tabs.create({
            url: 'https://login.taobao.com/member/login.jhtml?style=minisimple&from=alimama&redirectURL=http://login.taobao.com/member/taobaoke/login.htm?is_login=1&full_redirect=true&c_isScure=true&quicklogin=true'
          }, loginTab => {
            setTimeout(_ => {
              chrome.tabs.sendMessage(loginTab.id, {
                type: 'send-userinfo',
                username: localStorage.getItem('username'),
                password: localStorage.getItem('password')
              })
            }, 10000)
          })
          chrome.tabs.remove(logoutTab.id)
        }, 2000)
      })
    });
  }

  // 10分钟后自检，登录是否成功
  // setTimeout(_ => {
  //   if (loginTime === 0) {
  //     reboot('AUTO');
  //   } else {
  //     loginTime = 0;
  //   }
  // }, 10 * 60 * 1000)
}

function getSpm () {
  if (localStorage.getItem('spm')) {
    return localStorage.getItem('spm');
  } else {
    return '';
  }
}

function parseUrlToObj (search) {
  let obj = {};
  let objArr = search.split('&');
  objArr.forEach(item => {
    let params = item.split('=');
    if (params.length === 2) {
      obj[params[0]] = params[1];
    }
  })
  return obj;
}

function openTbkWin () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 580,
    left: 0,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/detail/taoke`,
    type: 'popup'
  }, window => {
    taokeId = window.id;

    // 10min后关闭窗口
    taokeTimeout = setTimeout(_ => {
      chrome.windows.remove(taokeId);
    }, 10 * 1000 * 60);
  });
}

function openTbkWinRestore () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 300,
    left: 600,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/detail/taoke?for=update`,
    type: 'popup'
  }, window => {
    taokeId = window.id;

    // 10min后关闭窗口
    taokeTimeout = setTimeout(_ => {
      chrome.windows.remove(taokeId);
    }, 10 * 1000 * 60);
  });
}

function openThirdServices (taokeId) {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 580,
    left: 0,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/detail/extra`,
    type: 'popup'
  }, window => {
    thirdId = window.id;
    // 先关掉淘客推广订单窗口
    byScript = true;
    taokeId && chrome.windows.remove(taokeId);

    // 3min后关闭窗口
    thirdTimeout = setTimeout(_ => {
      chrome.windows.remove(thirdId);
    }, 5 * 1000 * 60);
  });
}

function openResetData () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 580,
    left: 600,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/detail/taoke?for=update`,
    type: 'popup'
  }, window => {
    resetId = window.id;
  });
}

function openStateWin () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 420,
    left: 0,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/zone/zone_self`,
    type: 'popup'
  }, window => {
    stateId = window.id;
    stateTimeout = setTimeout(_ => {
      chrome.windows.remove(stateId);
    }, 20 * 1000 * 60);
  });
}

function openRightsWin () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 420,
    left: 600,
    url: `http://pub.alimama.com/myunion.htm?spm=${getSpm()}#!/report/detail/rights`,
    type: 'popup'
  }, window => {
    rightId = window.id;
    rightTimeout = setTimeout(_ => {
      chrome.windows.remove(rightId);
    }, 20 * 1000 * 60);
  });
}

function openAlimamaWin () {
  chrome.windows.create({
    focused: true,
    width: 10,
    height: 10,
    top: 650,
    left: 0,
    url: 'http://pub.alimama.com?type=forLogin',
    type: 'popup'
  }, window => {
    loginId = window.id;
    alimamaId = null;

    // 30s后跳转登录
    loginTimeout = setTimeout(_ => {

      // 关闭跳转窗口，打开登录窗口
      chrome.windows.create({
        focused: true,
        width: 10,
        height: 10,
        top: 650,
        left: 0,
        url: `https://login.taobao.com/aso/tgs?domain=alimama&sign_account=${localStorage.getItem('sign_account')}&service=user_on_taobao&target=${localStorage.getItem('target')}`,
        type: 'popup'
      }, window => {
        alimamaId = window.id;
        chrome.windows.remove(loginId);
        console.log(`https://login.taobao.com/aso/tgs?domain=alimama&sign_account=${localStorage.getItem('sign_account')}&service=user_on_taobao&target=${localStorage.getItem('target')}`);
        alimamaTimeout = setTimeout(_ => {
          chrome.windows.remove(alimamaId);
        }, 60 * 1000 * 6.5);
      });
    }, 30 * 1000)
  });
}