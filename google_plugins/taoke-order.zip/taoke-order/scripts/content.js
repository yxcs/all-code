﻿let mouseEvent = document.createEvent('MouseEvent');
let clickEvent = document.createEvent('MouseEvent');
let username = sessionStorage.getItem('username');
let password = sessionStorage.getItem('password');
let infoReceived = false;
mouseEvent.initMouseEvent('mousedown', true, true, document.defaultView, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
clickEvent.initMouseEvent('click', true, true, document.defaultView, 0, 0, 0, 0, 0, false, false, false, false, 0, null)

if (username && password) {
  infoReceived = true;
}

// 获取登录信息
chrome.runtime.onMessage.addListener((req, sender, sendRes) => {
  if (req.type === 'send-userinfo') {
    username = req.username;
    password = req.password;
    sessionStorage.setItem('username', username);
    sessionStorage.setItem('password', password);
    infoReceived = true;
  }
})

if (location.href.indexOf('/report/detail/taoke') !== - 1) {
  let _tb_token_ = '';
  let startTime = '';
  let endTime = '';
  let abateStart = '';
  let queryType = 1;
  let day = 0;
  let month = 0;
  let year = 0;
  let req = null;
  let downloadBtn = null;
  let isForUpdate = false;
  let startRstTime = null;

  let findBtnInterval = setInterval(() => {
    if (downloadBtn) {
      clearInterval(findBtnInterval);
      // 在downloadBtn前面插入结算时间的下载按钮
      updateDate();
      downloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=1&payStatus=&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${startTime}&endTime=${endTime}`;
       let newDownloadBtn = downloadBtn.cloneNode();
      let abateDownloadBtn = downloadBtn.cloneNode();
      let parent = downloadBtn.parentNode;
      let observer = new MutationObserver(mutations => {
        newDownloadBtn.dispatchEvent(mouseEvent);
        setTimeout(_ => {
            newDownloadBtn.dispatchEvent(clickEvent);
         }, 500)
            // 5s 后， 点击订单数失效
         setTimeout(_ => {
           abateDownloadBtn.dispatchEvent(mouseEvent);
           setTimeout(_ => {
             abateDownloadBtn.click();
           }, 500)
         }, 5000)

         setTimeout(_ => {
          downloadBtn.dispatchEvent(mouseEvent);
          setTimeout(_ => {
            downloadBtn.click();
          }, 500)
          setTimeout(_ => {
            location.href = `http://pub.alimama.com/myunion.htm?spm=${localStorage.getItem('spm')}#!/report/detail/extra`;
             setTimeout(_ => {
               location.reload(true);
            }, 10000)
          }, 60 * 1000 * 7)
         }, 10000);
      });
      let config = {
        childList: true
      };
       newDownloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=3&payStatus=3&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${startTime}&endTime=${endTime}`;
       abateDownloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=1&payStatus=13&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${abateStart}&endTime=${endTime}`;
       observer.observe(parent, config);
       downloadBtn.parentNode.insertBefore(abateDownloadBtn, downloadBtn);
       downloadBtn.parentNode.insertBefore(newDownloadBtn, downloadBtn);
     } else {
       downloadBtn = document.querySelector('[title="下载报表"]');
     }
  }, 500);

  let updateDate = () => {
    let endDate = new Date();
    let startDate = new Date(endDate - 60 * 1000 * 60 * 24 * 3);
    let abateDate = new Date(endDate - 60 * 1000 * 60 * 24 * 30);
    let endYear = endDate.getFullYear();
    let startYear = startDate.getFullYear();
    let abateStartYear = abateDate.getFullYear();
    let endMonth = endDate.getMonth() + 1;
    let startMonth = startDate.getMonth() + 1;
    let abateStartMonth = abateDate.getMonth() + 1;
    let endDay = endDate.getDate();
    let startDay = startDate.getDate();
    let abateStartDay = abateDate.getDate();
    if (endMonth < 10) {
      endMonth = '0' + endMonth.toString();
     }
    if (startMonth < 10) {
       startMonth = '0' + startMonth.toString();
    }
     if (endDay < 10) {
      endDay = '0' + endDay.toString();
     }
    if (startDay < 10) {
      startDay = '0' + startDay.toString();
     }
     endTime = endYear + '-' + endMonth + '-' + endDay;
     startTime = startYear + '-' + startMonth + '-' + startDay;
     abateStart = abateStartYear + '-' + abateStartMonth + '-' + abateStartDay;
  }

} else if (location.href.indexOf('/report/zone/zone_self') !== - 1) {
  let _tb_token_ = '';
  let startTime = '';
  let endTime = '';
  let queryType = 1;
  let day = 0;
  let month = 0;
  let year = 0;
  let req = null;
  let downloadBtn = null;

  let findBtnInterval = setInterval(() => {
    if (downloadBtn) {
      clearInterval(findBtnInterval);
      updateData();
      // 60分钟更新一次推广数据
      // setInterval(_ => {
      //   updateData();
      // },  60000 * 60);
    } else {
      downloadBtn = document.querySelector('[title="下载报表"]');
    }
  }, 500);

  let updateDate = () => {
    let endDate = new Date();
    let startDate = new Date(endDate - 60 * 1000 * 60 * 24 * 3);
    let endYear = endDate.getFullYear();
    let startYear = startDate.getFullYear();
    let endMonth = endDate.getMonth() + 1;
    let startMonth = startDate.getMonth() + 1;
    let endDay = endDate.getDate();
    let startDay = startDate.getDate();
    if (endMonth < 10) {
      endMonth = '0' + endMonth.toString();
    }
    if (startMonth < 10) {
      startMonth = '0' + startMonth.toString();
    }
    if (endDay < 10) {
      endDay = '0' + endDay.toString();
    }
    if (startDay < 10) {
      startDay = '0' + startDay.toString();
    }
    endTime = endYear + '-' + endMonth + '-' + endDay;
    startTime = startYear + '-' + startMonth + '-' + startDay;
  }

  let updateData = () => {
    updateDate();
    let zoneHref = `/report/selfRpt.json?DownloadID=DOWNLOAD_REPORT_REBORN_DETAIL&adzoneId=&startTime=${startTime}&endTime=${endTime}`;
    downloadBtn.href = zoneHref;
    downloadBtn.dispatchEvent(mouseEvent);
    downloadBtn.dispatchEvent(clickEvent);
  };
} else if (location.href.indexOf('/report/detail/rights') !== - 1) {
  let _tb_token_ = '';
  let startTime = '';
  let endTime = '';
  let queryType = 1;
  let day = 0;
  let month = 0;
  let year = 0;
  let req = null;
  let downloadBtn = null;

  let findBtnInterval = setInterval(() => {
    if (downloadBtn) {
      clearInterval(findBtnInterval);
      updateData();
    } else {
      downloadBtn = document.querySelector('[title="下载报表"]');
    }
  }, 500);

  let updateDate = () => {
    let endDate = new Date();
    let startDate = new Date(endDate - 60 * 1000 * 60 * 24 * 30);
    let endYear = endDate.getFullYear();
    let startYear = startDate.getFullYear();
    let endMonth = endDate.getMonth() + 1;
    let startMonth = startDate.getMonth() + 1;
    let endDay = endDate.getDate();
    let startDay = startDate.getDate();
    if (endMonth < 10) {
      endMonth = '0' + endMonth.toString();
    }
    if (startMonth < 10) {
      startMonth = '0' + startMonth.toString();
    }
    if (endDay < 10) {
      endDay = '0' + endDay.toString();
    }
    if (startDay < 10) {
      startDay = '0' + startDay.toString();
    }
    endTime = endYear + '-' + endMonth + '-' + endDay;
    startTime = startYear + '-' + startMonth + '-' + startDay;
  }

  let updateData = () => {
    updateDate();
    let rightsHref = `/report/getNewTbkRefundPaymentDetails.json?refundType=1&searchType=3&DownloadID=DOWNLOAD_EXPORT_CPSPAYMENT_REFUND_OVERVIEW&startTime=${startTime}&endTime=${endTime}`;
    downloadBtn.href = rightsHref;
    downloadBtn.dispatchEvent(mouseEvent);
    downloadBtn.dispatchEvent(clickEvent);
  };
} else if (location.href.indexOf('/report/detail/extra') !== - 1) {
  let startTime = '';
  let endTime = '';
  let abateStart = '';
  let day = 0;
  let month = 0;
  let year = 0;
  let req = null;
  let downloadBtn = null;
  let isForUpdate = false;
  let findBtnInterval = setInterval(() => {
    if (downloadBtn) {
      clearInterval(findBtnInterval);
      // 在downloadBtn前面插入结算时间的下载按钮
      updateDate();

      downloadBtn.href = `/report/getTbkThirdPaymentDetails.json?queryType=2&payStatus=&DownloadID=DOWNLOAD_REPORT_TK3_PUB&startTime=${startTime}&endTime=${endTime}`;
      let newDownloadBtn = downloadBtn.cloneNode();
      let abateDownloadBtn = downloadBtn.cloneNode();
      let parent = downloadBtn.parentNode;
      let observer = new MutationObserver(mutations => {
        newDownloadBtn.dispatchEvent(mouseEvent);
        newDownloadBtn.dispatchEvent(clickEvent);
        setTimeout(_ => {
          abateDownloadBtn.dispatchEvent(mouseEvent);
          abateDownloadBtn.click();
        }, 30000)
        setTimeout(_ => {
          downloadBtn.click();
        }, 60000);
      });
      let config = {
        childList: true
      };

      newDownloadBtn.href = `/report/getTbkThirdPaymentDetails.json?queryType=4&payStatus=3&DownloadID=DOWNLOAD_REPORT_TK3_PUB&startTime=${startTime}&endTime=${endTime}`;
      abateDownloadBtn.href = `/report/getTbkThirdPaymentDetails.json?queryType=2&payStatus=13&DownloadID=DOWNLOAD_REPORT_TK3_PUB&startTime=${abateStart}&endTime=${endTime}`;
      observer.observe(parent, config);
      downloadBtn.parentNode.insertBefore(newDownloadBtn, downloadBtn);
      downloadBtn.parentNode.insertBefore(abateDownloadBtn, downloadBtn);
    } else {
      downloadBtn = document.querySelector('[title="下载报表"]');
    }
  }, 500);

  let updateDate = () => {
    let endDate = new Date();
    let startDate = new Date(endDate - 60 * 1000 * 60 * 24 * 3);
    let abateDate = new Date(endDate - 60 * 1000 * 60 * 24 * 30);
    let endYear = endDate.getFullYear();
    let startYear = startDate.getFullYear();
    let abateStartYear = abateDate.getFullYear();
    let endMonth = endDate.getMonth() + 1;
    let startMonth = startDate.getMonth() + 1;
    let abateStartMonth = abateDate.getMonth() + 1;
    let endDay = endDate.getDate();
    let startDay = startDate.getDate();
    let abateStartDay = abateDate.getDate();
    if (endMonth < 10) {
      endMonth = '0' + endMonth.toString();
    }
    if (startMonth < 10) {
      startMonth = '0' + startMonth.toString();
    }
    if (endDay < 10) {
      endDay = '0' + endDay.toString();
    }
    if (startDay < 10) {
      startDay = '0' + startDay.toString();
    }
    endTime = endYear + '-' + endMonth + '-' + endDay;
    startTime = startYear + '-' + startMonth + '-' + startDay;
    abateStart = abateStartYear + '-' + abateStartMonth + '-' + abateStartDay;
  }
} else {
  // 维持登录
  // if (location.href.indexOf(`http://pub.alimama.com/myunion.htm?spm=${localStorage.getItem('spm')}`) !== -1) {
  //   let intervalId = setInterval(_ => {
  //     let btn = document.querySelector('.close');
  //     let messageTrigger = document.querySelector('.message-trigger');
  //     let travel = (mouseEvent, clickEvent) => {
  //       // 走一遍页面
  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/myunion/overview"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/myunion/overview"]').dispatchEvent(clickEvent)
  //       }, 1000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/myunion/message"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/myunion/message"]').dispatchEvent(clickEvent)
  //       }, 2000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/self/items"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/self/items"]').dispatchEvent(clickEvent)
  //       }, 3000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/self/links"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/self/links"]').dispatchEvent(clickEvent)
  //       }, 4000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/taobao/widget_publish"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/taobao/widget_publish"]').dispatchEvent(clickEvent)
  //       }, 5000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/taobao/coupon"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/taobao/coupon"]').dispatchEvent(clickEvent)
  //       }, 6000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/taobao/software"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/taobao/software"]').dispatchEvent(clickEvent)
  //       }, 7000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/act/activity"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/act/activity"]').dispatchEvent(clickEvent)
  //       }, 8000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/act/activity_seller"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/act/activity_seller"]').dispatchEvent(clickEvent)
  //       }, 9000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/act/activity_cpa"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/act/activity_cpa"]').dispatchEvent(clickEvent)
  //       }, 10000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/extra/aliyun"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/extra/aliyun"]').dispatchEvent(clickEvent)
  //       }, 11000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/promo/extra/alitrip"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/promo/extra/alitrip"]').dispatchEvent(clickEvent)
  //       }, 12000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/manage/site/site"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/manage/site/site"]').dispatchEvent(clickEvent)
  //       }, 13000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/manage/zone/zone"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/manage/zone/zone"]').dispatchEvent(clickEvent)
  //       }, 14000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/manage/channel/channel"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/manage/channel/channel"]').dispatchEvent(clickEvent)
  //       }, 15000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/manage/campaign/campaign"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/manage/campaign/campaign"]').dispatchEvent(clickEvent)
  //       }, 16000)

  //       setTimeout(_ => {
  //         document.querySelector('[href="#!/manage/software/list"]').dispatchEvent(mouseEvent)
  //         document.querySelector('[href="#!/manage/software/list"]').dispatchEvent(clickEvent)
  //       }, 17000)
  //     }
  //     if (btn) {
  //       clearInterval(intervalId);
  //       let mouseEvent = document.createEvent('MouseEvent');
  //       mouseEvent.initMouseEvent('mousedown', true, true, document.defaultView, 0, 0, 0, 0, 0, false, false, false, false, 0, null)

  //       // 隐藏公告
  //       btn.dispatchEvent(mouseEvent);

  //       setTimeout(_ => {
  //         travel(mouseEvent, clickEvent)
  //       }, 10000)
  //     } else if (messageTrigger) {
  //       clearInterval(intervalId);

  //       // 展现公告
  //       messageTrigger.dispatchEvent(mouseEvent);
  //       messageTrigger.dispatchEvent(clickEvent);

  //       setTimeout(_ => {
  //         travel(mouseEvent, clickEvent)
  //       }, 10000)
  //     }

  //   }, 500);
  // }
}

// 当跳转到阿里妈妈首页时，获取并设置spm
if (location.href === 'https://pub.alimama.com/' ||
location.href === 'http://pub.alimama.com/') {
  let intervalId = setInterval(_ => {
    let btn = document.querySelector('a.login-enter');
    if (btn) {
      clearInterval(intervalId);
      btn.onclick = function (e) {
        let nextHref = e.target.href;
        let spm = nextHref.split('?spm=')[1];
        localStorage.setItem('spm', spm);
        chrome.runtime.sendMessage({type: 'login-succeed', spm});
      }

      // 模拟mousedown事件，生成spm
      let mouseEvent = document.createEvent('MouseEvent')
      mouseEvent.initMouseEvent('mousedown', true, true, document.defaultView, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
      btn.dispatchEvent(mouseEvent);
      setTimeout(_ => {
        btn.click();
      }, 1500)
    }
  }, 2000);
}

if (location.href.indexOf('https://login.taobao.com/member/login.jhtml') === 0) {
  let passwordEle = null;
  let usernameEle = null;
  let loginBtn = null;
  // let passwordInput = null;
  let loginBtnInterval = setInterval(_ => {

    // 登录按钮是否加载完成
    loginBtn = document.querySelector('#J_SubmitStatic');
    if (loginBtn) {
      clearInterval(loginBtnInterval);
      loginBtn.textContent = '自动登录中，请稍等...';
      loginBtn.disabled = true;

      // 判断用户名和密码输入框是否渲染完成
      let inputInterval = setInterval(_ => {
        passwordEle = document.querySelector('#TPL_password_1');
        usernameEle = document.querySelector('#TPL_username_1');
        if (passwordEle && usernameEle && infoReceived) {
          clearInterval(inputInterval);
          loginBtn.onclick = function () {
            password = passwordEle.value;
            username = usernameEle.value;
            chrome.runtime.sendMessage({type: 'get-userinfo', username, password});
          }

          // 判断是否有滑动验证组件,
          // 如果没有滑动验证组件，直接登录
          if (
            window.getComputedStyle(
              document.querySelector('#nocaptcha')
            ).display === 'none') {
            passwordEle.value = password;
            usernameEle.value = username;
            loginBtn.textContent = `登    录`;
            loginBtn.disabled = false;
            setTimeout(_ => {
              document.querySelector('#J_SubmitStatic').click();
            }, 2000)
          } else {

            // 如果有滑动验证组件，先改名，方便通过滑动验证
            passwordEle.value = password;
            usernameEle.value = username + new Date().getMilliseconds();

            // 开始滑动验证逻辑
            let btn = document.querySelector('#nc_1_n1z');
            let bg = document.querySelector('#nc_1__bg');


            mouseDownStart = new MouseEvent('mousedown', {
              clientX: 800,
              clientY: 400,
              view: window,
              buttons: 1,
              button: 0,
              bubbles: true,
              cancelable: true
            })
            mouseDown = new MouseEvent('mousedown', {
              clientX: 800,
              clientY: 400,
              view: window,
              buttons: 1,
              button: 0,
              bubbles: true,
              cancelable: true
            })
            mouseMove = new MouseEvent('mousemove', {
              clientX: 800,
              clientY: 400,
              view: window,
              buttons: 1,
              button: 0,
              bubbles: true,
              cancelable: true
            })
            mouseMoveEnd = new MouseEvent('mousemove', {
              clientX: 900,
              clientY: 400,
              view: window,
              buttons: 1,
              button: 0,
              bubbles: true,
              cancelable: true
            })

            btn.dispatchEvent(mouseDownStart);

            document.dispatchEvent(mouseMove);

            setTimeout(_ => {
              btn.style.left = '210px';
              bg.style.width = '210px';
              "210px"
            }, 500)

            setTimeout(_ => {
              btn.dispatchEvent(mouseDown);
              document.dispatchEvent(mouseMove);
              loginBtn.disabled = false;
              loginBtn.textContent = `登    录`;

              // 改回正确昵称
              setTimeout(_ => {
                usernameEle.value = username;

                setTimeout(_ => {
                  document.querySelector('#J_SubmitStatic').click();
                }, 2000)
              }, 2000)
            }, 1000)
          }
        }
      }, 200)
    }
  }, 200);
}

// 用于进行恢复数据，不影响其他任务
if(location.href.indexOf('/report/detail/taoke?for=update') > 0) {
  let _tb_token_ = '';
  let startTime = '';
  let endTime = '';
  let abateStart = '';
  let queryType = 1;
  let day = 0;
  let month = 0;
  let year = 0;
  let req = null;
  let downloadBtn = null;
  let isForUpdate = false;
  let startRstTime = null;

  console.log('for=update')
  // 只能够获取最近90天的表单
  startRstTime = new Date(new Date().getTime() - 60 * 1000 * 60 * 24 * 90);
  let findBtnInterval = setInterval(() => {
    if (downloadBtn) {
      clearInterval(findBtnInterval);
      // 开始恢复数据，30s下载一天数据
      let rstInterval = setInterval(_ => {
        updateDate();
        // 判断数据恢复是否完成
        if (endTime >= new Date(new Date(new Date().getTime() - 60 * 1000 * 60 * 24).toLocaleDateString()).getTime()) {
          clearInterval(rstInterval);
          console.log('数据恢复已结束');
        } else {
          console.log(startTime)
          let newDownloadBtn = downloadBtn.cloneNode();
          let abateDownloadBtn = downloadBtn.cloneNode();  // 失效按钮
          let parent = downloadBtn.parentNode;
          newDownloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=3&payStatus=3&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${startTime}&endTime=${endTime}`;
          downloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=1&payStatus=&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${startTime}&endTime=${endTime}`;
          abateDownloadBtn.href = `/report/getTbkPaymentDetails.json?queryType=1&payStatus=13&DownloadID=DOWNLOAD_REPORT_INCOME_NEW&startTime=${startTime}&endTime=${endTime}`;
          parent.insertBefore(newDownloadBtn, downloadBtn);
          parent.insertBefore(abateDownloadBtn, downloadBtn);
          setTimeout(_ => {
            newDownloadBtn.click();
            newDownloadBtn.remove();
          }, 500);
          setTimeout(_ => {
            abateDownloadBtn.click();
            abateDownloadBtn.remove();
          }, 1000);
          downloadBtn.click();
        }
      }, 30000);
    } else {
      downloadBtn = document.querySelector('[title="下载报表"]');
    }
  }, 500);

  let updateDate = () => {
    let endDate = startRstTime;
    let startDate = startRstTime;
    let endYear = endDate.getFullYear();
    let startYear = startDate.getFullYear();
    let endMonth = endDate.getMonth() + 1;
    let startMonth = startDate.getMonth() + 1;
    let endDay = endDate.getDate();
    let startDay = startDate.getDate();
    if (endMonth < 10) {
      endMonth = '0' + endMonth.toString();
    }
    if (startMonth < 10) {
      startMonth = '0' + startMonth.toString();
    }
    if (endDay < 10) {
      endDay = '0' + endDay.toString();
    }
    if (startDay < 10) {
      startDay = '0' + startDay.toString();
    }
    endTime = endYear + '-' + endMonth + '-' + endDay;
    startTime = startYear + '-' + startMonth + '-' + startDay;
    startRstTime = new Date(startRstTime.getTime() + 60 * 1000 * 60 * 24);
    console.log(startRstTime.toLocaleString());
  }
}