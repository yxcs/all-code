// chrome.devtools.network.onRequestFinished.addListener(req => {
//   chrome.runtime.sendMessage({type: 'get-request', req});
// })